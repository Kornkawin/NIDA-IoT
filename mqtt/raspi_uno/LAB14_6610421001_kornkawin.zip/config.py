mqtt_server_host = "127.0.0.1"
mqtt_server_port = 1883
mqtt_keepalive = 60
username = "iot123"
password = "iot123"
serial_port = '/dev/cu.usbmodem1113101'
